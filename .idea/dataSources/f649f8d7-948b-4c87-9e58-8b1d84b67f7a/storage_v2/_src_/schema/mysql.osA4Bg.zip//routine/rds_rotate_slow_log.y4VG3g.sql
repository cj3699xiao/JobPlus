create
    definer = rdsadmin@localhost procedure rds_rotate_slow_log()
BEGIN
  DECLARE sql_logging BOOLEAN;
  select @@sql_log_bin into sql_logging;
  set @@sql_log_bin=off;
  CREATE TABLE IF NOT EXISTS mysql.slow_log_template LIKE mysql.slow_log;
  CREATE TABLE IF NOT EXISTS mysql.slow_log2 LIKE mysql.slow_log_template;
  DROP TABLE IF EXISTS mysql.slow_log_backup;
  RENAME TABLE mysql.slow_log TO mysql.slow_log_backup, mysql.slow_log2 TO mysql.slow_log;
  set @@sql_log_bin=sql_logging;
END;

